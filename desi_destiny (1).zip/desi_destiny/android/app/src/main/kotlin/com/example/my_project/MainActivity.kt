package com.mycompany.desidestiny

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
