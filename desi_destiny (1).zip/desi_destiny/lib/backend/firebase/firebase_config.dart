import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyAa1lnnIGXaaRIP2_Xe9vUBQODmvUQdZ7c",
            authDomain: "desi-destiny-47kesl.firebaseapp.com",
            projectId: "desi-destiny-47kesl",
            storageBucket: "desi-destiny-47kesl.appspot.com",
            messagingSenderId: "207164556163",
            appId: "1:207164556163:web:cab3fb9e05ce69af70ecb6"));
  } else {
    await Firebase.initializeApp();
  }
}
