// Export pages
export '/login/login_widget.dart' show LoginWidget;
export '/preference_page/preference_page_widget.dart' show PreferencePageWidget;
export '/user_i_d/user_i_d_widget.dart' show UserIDWidget;
export '/user_i_d2page/user_i_d2page_widget.dart' show UserID2pageWidget;
export '/photopage/photopage_widget.dart' show PhotopageWidget;
export '/life_goals/life_goals_widget.dart' show LifeGoalsWidget;
export '/my_profile/my_profile_widget.dart' show MyProfileWidget;
export '/swip_page/swip_page_widget.dart' show SwipPageWidget;
export '/chatpage/chatpage_widget.dart' show ChatpageWidget;
export '/chatbot/chatbot_widget.dart' show ChatbotWidget;
export '/likepage/likepage_widget.dart' show LikepageWidget;
