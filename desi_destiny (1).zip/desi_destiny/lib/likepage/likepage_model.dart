import '/flutter_flow/flutter_flow_util.dart';
import 'likepage_widget.dart' show LikepageWidget;
import 'package:flutter/material.dart';

class LikepageModel extends FlutterFlowModel<LikepageWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
